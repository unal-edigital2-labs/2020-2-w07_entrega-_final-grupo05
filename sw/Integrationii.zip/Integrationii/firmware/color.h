
#define color_black				0x000
#define color_blue				0x00A
#define color_green				0x0A0
#define color_cyan				0x0AA
#define color_red				0xA00
#define color_magenta			0xA0A
#define color_brown				0xA50
#define color_gray				0xAAA
#define color_dark_gray			0x555
#define color_bright_blue		0x55F
#define color_bright_green		0x5F5
#define color_bright_cyan		0x5FF
#define color_bright_red		0xF55
#define color_bright_magenta	0xF5F
#define color_yellow			0xFF5
#define color_white				0xFFF

