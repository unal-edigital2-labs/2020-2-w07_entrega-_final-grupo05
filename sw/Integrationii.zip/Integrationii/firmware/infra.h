#ifndef __INFRA_H
#define __INFRA_H

#ifdef __cplusplus
extern "C" {
#endif


void infra_isr(void);
void infra_init(void);

#ifdef __cplusplus
}
#endif

#endif
