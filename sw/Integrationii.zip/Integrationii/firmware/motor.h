#ifndef __MOTOR_H
#define __MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif


void motor_isr(void);
void motor_init(void);

#ifdef __cplusplus
}
#endif

#endif
