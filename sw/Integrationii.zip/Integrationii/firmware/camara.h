#ifndef __CAMARA_H
#define __CAMARA_H

#ifdef __cplusplus
extern "C" {
#endif


void camara_isr(void);
void camara_init(void);

#ifdef __cplusplus
}
#endif

#endif
