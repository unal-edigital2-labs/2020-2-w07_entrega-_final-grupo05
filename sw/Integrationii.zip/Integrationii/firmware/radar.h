#ifndef __RADAR_H
#define __RADAR_H

#ifdef __cplusplus
extern "C" {
#endif


void radar_isr(void);
void radar_init(void);

#ifdef __cplusplus
}
#endif

#endif
