#ifndef _DELAY
#define _DELAY

void delay(unsigned int ds);

void delay_ms(unsigned int ds);

void delay_us(unsigned int ds);

#endif
