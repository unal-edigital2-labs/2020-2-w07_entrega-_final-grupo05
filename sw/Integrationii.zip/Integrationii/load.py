#!/usr/bin/env python3

import os

os.system("djtgcfg prog -d NexysA7 -i 0 -f ./build/nexys4ddr/gateware/nexys4ddr.bit")
